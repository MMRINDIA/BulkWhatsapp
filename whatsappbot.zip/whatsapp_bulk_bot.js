"""
WhatsApp Bulk Sender Bot
Integrates with BulkMessageManager to send messages with rate limiting
"""
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const axios = require('axios');
const fs = require('fs').promises;

class WhatsAppBulkSender {
    constructor() {
        this.client = new Client({
            authStrategy: new LocalAuth(),
            puppeteer: {
                headless: true,
                args: ['--no-sandbox']
            }
        });
        
        this.config = {
            backendUrl: 'http://localhost:5050',
            batchDelay: 3600000, // 1 hour in ms
            messageDelay: 60000,  // 1 minute in ms
            randomizeDelay: true
        };
        
        this.isSending = false;
        this.currentCampaign = null;
    }
    
    async initialize() {
        console.log('🚀 Initializing WhatsApp Bulk Sender...\n');
        
        // QR Code
        this.client.on('qr', (qr) => {
            console.log('📱 Scan this QR code with WhatsApp:\n');
            qrcode.generate(qr, { small: true });
        });
        
        // Ready
        this.client.on('ready', async () => {
            console.log('✅ WhatsApp Bulk Sender is ready!\n');
            this.startBulkSending();
        });
        
        // Message received (for control commands)
        this.client.on('message', async (msg) => {
            await this.handleCommand(msg);
        });
        
        // Error handling
        this.client.on('auth_failure', () => {
            console.error('❌ Authentication failed');
        });
        
        this.client.on('disconnected', () => {
            console.log('⚠️  Client disconnected');
        });
        
        await this.client.initialize();
    }
    
    async handleCommand(msg) {
        const command = msg.body.toLowerCase().trim();
        const from = msg.from;
        
        // Only respond to specific admin number (optional)
        // if (from !== 'ADMIN_NUMBER@c.us') return;
        
        if (command === 'bulk status') {
            const stats = await this.getStats();
            await msg.reply(this.formatStats(stats));
        }
        else if (command === 'bulk pause') {
            this.isSending = false;
            await msg.reply('⏸️  Bulk sending paused');
        }
        else if (command === 'bulk resume') {
            this.isSending = true;
            await msg.reply('▶️  Bulk sending resumed');
            this.startBulkSending();
        }
        else if (command === 'bulk stop') {
            this.isSending = false;
            if (this.currentCampaign) {
                await this.pauseCampaign(this.currentCampaign);
            }
            await msg.reply('🛑 Bulk sending stopped');
        }
    }
    
    async startBulkSending() {
        console.log('📤 Starting bulk message sender...\n');
        
        while (true) {
            try {
                if (!this.isSending) {
                    console.log('⏸️  Sending paused. Waiting...');
                    await this.sleep(60000); // Check every minute
                    continue;
                }
                
                // Get next batch from backend
                const batch = await this.getNextBatch();
                
                if (!batch || batch.length === 0) {
                    console.log('📭 No messages in queue. Waiting 5 minutes...');
                    await this.sleep(300000); // 5 minutes
                    continue;
                }
                
                console.log(`\n📨 Processing batch of ${batch.length} messages...\n`);
                
                // Send each message in the batch
                for (let i = 0; i < batch.length; i++) {
                    const item = batch[i];
                    
                    try {
                        await this.sendMessage(item);
                        console.log(`✅ [${i + 1}/${batch.length}] Sent to ${item.contact.name || item.contact.phone}`);
                        
                        // Log success
                        await this.logMessage(item.campaign_id, item.contact, true);
                        
                        // Delay between messages (with randomization to appear more human)
                        if (i < batch.length - 1) {
                            const delay = this.getRandomDelay(this.config.messageDelay);
                            console.log(`⏳ Waiting ${Math.round(delay / 1000)}s before next message...`);
                            await this.sleep(delay);
                        }
                    }
                    catch (error) {
                        console.error(`❌ [${i + 1}/${batch.length}] Failed to send to ${item.contact.phone}: ${error.message}`);
                        
                        // Log failure
                        await this.logMessage(item.campaign_id, item.contact, false, error.message);
                    }
                }
                
                console.log(`\n✅ Batch completed!\n`);
                
                // Get stats
                const stats = await this.getStats();
                console.log(this.formatStats(stats));
                
                // Wait before next batch (1 hour with randomization)
                const batchDelay = this.getRandomDelay(this.config.batchDelay);
                console.log(`\n⏰ Next batch in ${Math.round(batchDelay / 60000)} minutes...\n`);
                console.log('=' + '='.repeat(60) + '\n');
                
                await this.sleep(batchDelay);
            }
            catch (error) {
                console.error('❌ Error in bulk sending loop:', error);
                await this.sleep(60000); // Wait 1 minute on error
            }
        }
    }
    
    async sendMessage(item) {
        const chatId = this.formatPhoneNumber(item.contact.phone);
        
        // Send the message
        await this.client.sendMessage(chatId, item.message);
        
        // Optional: Add typing indicator for more human-like behavior
        // await this.client.sendPresenceAvailable();
    }
    
    formatPhoneNumber(phone) {
        // Remove any non-digit characters
        let cleaned = phone.replace(/\D/g, '');
        
        // Add @c.us suffix
        return cleaned + '@c.us';
    }
    
    getRandomDelay(baseDelay) {
        if (!this.config.randomizeDelay) {
            return baseDelay;
        }
        
        // Add ±20% randomization
        const variance = baseDelay * 0.2;
        const randomVariance = (Math.random() * 2 - 1) * variance;
        
        return Math.round(baseDelay + randomVariance);
    }
    
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // ==================== BACKEND COMMUNICATION ====================
    
    async getNextBatch() {
        try {
            const response = await axios.get(`${this.config.backendUrl}/bulk/next-batch`);
            return response.data.batch || [];
        }
        catch (error) {
            console.error('Error getting next batch:', error.message);
            return [];
        }
    }
    
    async logMessage(campaignId, contact, success, error = null) {
        try {
            await axios.post(`${this.config.backendUrl}/bulk/log`, {
                campaign_id: campaignId,
                contact: contact,
                success: success,
                error: error
            });
        }
        catch (err) {
            console.error('Error logging message:', err.message);
        }
    }
    
    async getStats() {
        try {
            const response = await axios.get(`${this.config.backendUrl}/bulk/stats`);
            return response.data;
        }
        catch (error) {
            console.error('Error getting stats:', error.message);
            return {};
        }
    }
    
    async pauseCampaign(campaignId) {
        try {
            await axios.post(`${this.config.backendUrl}/bulk/pause`, {
                campaign_id: campaignId
            });
        }
        catch (error) {
            console.error('Error pausing campaign:', error.message);
        }
    }
    
    formatStats(stats) {
        if (!stats || !stats.daily) {
            return '📊 No stats available';
        }
        
        return `📊 Bulk Sending Stats
        
Today's Progress:
━━━━━━━━━━━━━━━━━━━━━━━━━
Sent: ${stats.daily.sent_today}/${stats.daily.sent_today + stats.daily.remaining_today}
Remaining: ${stats.daily.remaining_today}

Current Hour:
━━━━━━━━━━━━━━━━━━━━━━━━━
Sent: ${stats.daily.hourly_sent}/${stats.daily.hourly_limit}
Available: ${stats.daily.hourly_remaining}

Active Campaigns: ${stats.active_campaigns || 0}`;
    }
}

// Start the bot
const bot = new WhatsAppBulkSender();
bot.initialize().catch(console.error);

module.exports = WhatsAppBulkSender;
