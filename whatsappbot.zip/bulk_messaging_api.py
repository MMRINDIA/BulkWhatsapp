"""
WhatsApp Bulk Messaging Backend API
Flask server that connects BulkMessageManager with WhatsApp bot
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
from bulk_message_manager import BulkMessageManager
import sys

app = Flask(__name__)
CORS(app)

# Initialize bulk message manager
manager = BulkMessageManager()

print("=" * 60)
print("🚀 WHATSAPP BULK MESSAGING API")
print("=" * 60)


# ==================== CAMPAIGN ENDPOINTS ====================

@app.route('/bulk/campaign/create', methods=['POST'])
def create_campaign():
    """Create a new bulk message campaign"""
    try:
        data = request.json
        
        campaign_id = manager.create_campaign(
            campaign_name=data['name'],
            template_ids=data['templates'],
            contact_tags=data.get('tags'),
            start_time=data.get('start_time')
        )
        
        return jsonify({
            'success': True,
            'campaign_id': campaign_id,
            'message': 'Campaign created successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/campaign/activate/<campaign_id>', methods=['POST'])
def activate_campaign(campaign_id):
    """Activate a campaign"""
    try:
        success = manager.activate_campaign(campaign_id)
        
        return jsonify({
            'success': success,
            'message': 'Campaign activated' if success else 'Campaign not found'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/campaign/pause/<campaign_id>', methods=['POST'])
def pause_campaign(campaign_id):
    """Pause a campaign"""
    try:
        success = manager.pause_campaign(campaign_id)
        
        return jsonify({
            'success': success,
            'message': 'Campaign paused' if success else 'Campaign not found'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/campaign/stats/<campaign_id>', methods=['GET'])
def get_campaign_stats(campaign_id):
    """Get campaign statistics"""
    try:
        stats = manager.get_campaign_stats(campaign_id)
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ==================== CONTACT ENDPOINTS ====================

@app.route('/bulk/contacts/add', methods=['POST'])
def add_contact():
    """Add a single contact"""
    try:
        data = request.json
        
        manager.add_contact(
            phone=data['phone'],
            name=data.get('name', ''),
            tags=data.get('tags', [])
        )
        
        return jsonify({
            'success': True,
            'message': 'Contact added successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/contacts/bulk-add', methods=['POST'])
def bulk_add_contacts():
    """Add multiple contacts"""
    try:
        data = request.json
        contacts = data.get('contacts', [])
        
        added = manager.add_contacts_bulk(contacts)
        
        return jsonify({
            'success': True,
            'added': added,
            'message': f'{added} contacts added'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/contacts/import-csv', methods=['POST'])
def import_csv():
    """Import contacts from CSV"""
    try:
        data = request.json
        csv_file = data.get('file_path')
        
        added = manager.import_contacts_from_csv(csv_file)
        
        return jsonify({
            'success': True,
            'added': added,
            'message': f'{added} contacts imported'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/contacts/list', methods=['GET'])
def list_contacts():
    """List all contacts"""
    try:
        tags = request.args.getlist('tags')
        contacts = manager.get_contacts(tags=tags if tags else None)
        
        return jsonify({
            'success': True,
            'contacts': contacts,
            'count': len(contacts)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/contacts/remove', methods=['DELETE'])
def remove_contact():
    """Remove a contact"""
    try:
        data = request.json
        phone = data.get('phone')
        
        success = manager.remove_contact(phone)
        
        return jsonify({
            'success': success,
            'message': 'Contact removed' if success else 'Contact not found'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ==================== TEMPLATE ENDPOINTS ====================

@app.route('/bulk/templates/add', methods=['POST'])
def add_template():
    """Add a message template"""
    try:
        data = request.json
        
        manager.add_template(
            template_id=data['id'],
            message=data['message'],
            variables=data.get('variables', [])
        )
        
        return jsonify({
            'success': True,
            'message': 'Template added successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/templates/list', methods=['GET'])
def list_templates():
    """List all templates"""
    try:
        templates = manager.list_templates()
        
        return jsonify({
            'success': True,
            'templates': templates
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ==================== SENDING ENDPOINTS ====================

@app.route('/bulk/next-batch', methods=['GET'])
def get_next_batch():
    """Get next batch of messages to send (called by WhatsApp bot)"""
    try:
        batch = manager.get_next_batch()
        
        return jsonify({
            'success': True,
            'batch': batch,
            'count': len(batch)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/log', methods=['POST'])
def log_message():
    """Log a sent message (called by WhatsApp bot)"""
    try:
        data = request.json
        
        manager.log_sent_message(
            campaign_id=data['campaign_id'],
            contact=data['contact'],
            success=data['success'],
            error=data.get('error')
        )
        
        return jsonify({
            'success': True,
            'message': 'Message logged'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


@app.route('/bulk/stats', methods=['GET'])
def get_stats():
    """Get current statistics"""
    try:
        daily_stats = manager.get_daily_stats()
        
        # Count active campaigns
        active_campaigns = sum(
            1 for campaign in manager.queue.values()
            if campaign['status'] == 'active'
        )
        
        return jsonify({
            'success': True,
            'daily': daily_stats,
            'active_campaigns': active_campaigns
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ==================== CONFIGURATION ENDPOINTS ====================

@app.route('/bulk/config', methods=['GET'])
def get_config():
    """Get current configuration"""
    return jsonify({
        'success': True,
        'config': manager.config
    })


@app.route('/bulk/config/update', methods=['POST'])
def update_config():
    """Update configuration"""
    try:
        data = request.json
        
        for key, value in data.items():
            if key in manager.config:
                manager.config[key] = value
        
        return jsonify({
            'success': True,
            'message': 'Configuration updated',
            'config': manager.config
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400


# ==================== HEALTH CHECK ====================

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'WhatsApp Bulk Messaging API'
    })


# ==================== START SERVER ====================

if __name__ == '__main__':
    print("\n📡 API Endpoints:")
    print("   Campaign: /bulk/campaign/*")
    print("   Contacts: /bulk/contacts/*")
    print("   Templates: /bulk/templates/*")
    print("   Sending: /bulk/next-batch, /bulk/log")
    print("   Stats: /bulk/stats")
    print("   Config: /bulk/config/*")
    print()
    print("🌐 Server starting on http://0.0.0.0:5050")
    print("=" * 60)
    print()
    
    app.run(host='0.0.0.0', port=5050, debug=True)
