# 📋 QUICK REFERENCE CARD

## 🚀 ONE-PAGE SETUP GUIDE

### ⚡ FAST SETUP (5 Commands)

```bash
# 1. Install dependencies
pip install flask flask-cors
npm install

# 2. Setup example data
python quick_start.py

# 3. Start API (Terminal 1)
python bulk_messaging_api.py

# 4. Start WhatsApp Bot (Terminal 2)
node whatsapp_bulk_bot.js

# 5. Activate campaign
curl -X POST http://localhost:5050/bulk/campaign/activate/CAMPAIGN_ID
```

**Done!** Messages will start sending automatically.

---

## 📊 SYSTEM WORKFLOW

```
┌─────────────────────────────────────────────────────────┐
│  YOU (Setup)                                            │
│  • Add contacts                                         │
│  • Create 5 message templates                           │
│  • Create campaign                                      │
│  • Activate campaign                                    │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  BULK MESSAGE MANAGER (Python)                          │
│  • Tracks credits (48/day, 5/hour)                      │
│  • Manages contacts & templates                         │
│  • Creates message batches                              │
│  • Rotates through templates                            │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  API SERVER (Flask)                                     │
│  http://localhost:5050                                  │
│  • GET /bulk/next-batch  ← Bot asks for messages       │
│  • POST /bulk/log        ← Bot logs sent messages      │
│  • GET /bulk/stats       ← Dashboard gets stats        │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  WHATSAPP BOT (Node.js)                                 │
│  • Gets 5 messages from API                             │
│  • Sends message #1 → Wait 60s                          │
│  • Sends message #2 → Wait 60s                          │
│  • Sends message #3 → Wait 60s                          │
│  • Sends message #4 → Wait 60s                          │
│  • Sends message #5                                     │
│  • Waits 1 hour                                         │
│  • Repeats (next 5 messages)                            │
└─────────────────┬───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│  WHATSAPP (Your Contacts)                               │
│  • Contact 1 receives: "Hi John! Welcome..."            │
│  • Contact 2 receives: "Hey Jane! Special offer..."     │
│  • Contact 3 receives: "Hello Bob, reminder..."         │
│  • Contact 4 receives: "Alice, following up..."         │
│  • Contact 5 receives: "Thank you Charlie..."           │
└─────────────────────────────────────────────────────────┘
```

---

## 📅 DAILY SCHEDULE EXAMPLE

```
08:00 AM │ Batch 1  │ Msg 1-5   │ Hour 1  │ 5 sent
09:00 AM │ Batch 2  │ Msg 6-10  │ Hour 2  │ 10 sent
10:00 AM │ Batch 3  │ Msg 11-15 │ Hour 3  │ 15 sent
11:00 AM │ Batch 4  │ Msg 16-20 │ Hour 4  │ 20 sent
12:00 PM │ Batch 5  │ Msg 21-25 │ Hour 5  │ 25 sent
01:00 PM │ Batch 6  │ Msg 26-30 │ Hour 6  │ 30 sent
02:00 PM │ Batch 7  │ Msg 31-35 │ Hour 7  │ 35 sent
03:00 PM │ Batch 8  │ Msg 36-40 │ Hour 8  │ 40 sent
04:00 PM │ Batch 9  │ Msg 41-45 │ Hour 9  │ 45 sent
05:00 PM │ Batch 10 │ Msg 46-48 │ Hour 10 │ 48 sent ✅
06:00 PM │ DONE     │ Daily limit reached     │
```

---

## 🎯 TERMINAL CHECKLIST

### ✅ What You Should See:

**Terminal 1 (API Server):**
```
🚀 WHATSAPP BULK MESSAGING API
🌐 Server starting on http://0.0.0.0:5050
* Running on http://127.0.0.1:5050
```

**Terminal 2 (WhatsApp Bot):**
```
🚀 Initializing WhatsApp Bulk Sender...
📱 Scan this QR code with WhatsApp:
[QR CODE]
✅ WhatsApp Bulk Sender is ready!
📤 Starting bulk message sender...
```

**After Activation:**
```
📨 Processing batch of 5 messages...
✅ [1/5] Sent to John Doe
⏳ Waiting 62s before next message...
✅ [2/5] Sent to Jane Smith
```

---

## 📞 WHATSAPP COMMANDS

Send these to your WhatsApp bot:

| Command | Action |
|---------|--------|
| `bulk status` | Show current stats |
| `bulk pause` | Pause sending |
| `bulk resume` | Resume sending |
| `bulk stop` | Stop all campaigns |

**Response Example:**
```
📊 Bulk Sending Stats

Today's Progress:
━━━━━━━━━━━━━━━━━━━━━━━━━
Sent: 15/48
Remaining: 33

Current Hour:
━━━━━━━━━━━━━━━━━━━━━━━━━
Sent: 3/5
Available: 2

Active Campaigns: 1
```

---

## 🔧 API ENDPOINTS

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/bulk/contacts/add` | POST | Add contact |
| `/bulk/templates/add` | POST | Add template |
| `/bulk/campaign/create` | POST | Create campaign |
| `/bulk/campaign/activate/<id>` | POST | Start campaign |
| `/bulk/campaign/pause/<id>` | POST | Pause campaign |
| `/bulk/stats` | GET | Get statistics |
| `/bulk/next-batch` | GET | Get messages (bot) |
| `/bulk/log` | POST | Log sent (bot) |

---

## 📝 FILE STRUCTURE

```
whatsapp-bulk-messaging/
├── bulk_message_manager.py      ← Core logic
├── bulk_messaging_api.py        ← REST API
├── whatsapp_bulk_bot.js         ← WhatsApp integration
├── bulk_messaging_dashboard.html ← Web interface
├── package.json                 ← Node dependencies
├── quick_start.py               ← Setup example data
├── BULK_MESSAGING_README.md     ← Full docs
└── HOW_TO_RUN.md               ← This guide

Data (auto-created):
~/.aiden/bulk_messages/
├── contacts.json                ← Your contacts
├── message_templates.json       ← Your templates
├── message_queue.json          ← Active campaigns
└── sent_log.json               ← Sent history
```

---

## ⚙️ SETTINGS

### Default Configuration:
```python
daily_limit: 48              # Messages per day
hourly_limit: 5              # Messages per hour
messages_per_batch: 5        # Batch size
delay_between_messages: 60   # Seconds
delay_between_batches: 3600  # Seconds (1 hour)
randomize_delay: True        # Add variance
```

### Change Settings:
1. Open dashboard → Settings tab
2. Or edit `bulk_messaging_api.py`:
```python
manager.config['daily_limit'] = 100
manager.config['hourly_limit'] = 10
```

---

## 🚨 IMPORTANT LIMITS

| Limit | Value | What Happens |
|-------|-------|--------------|
| **Daily** | 48 messages | System stops at 48, resumes next day |
| **Hourly** | 5 messages | System waits 1 hour before next batch |
| **Batch** | 5 messages | Send 5 together, then wait |
| **Delay** | 60 seconds | Wait between each message |

**These limits prevent WhatsApp from blocking you!**

---

## 📱 PHONE NUMBER FORMAT

| ❌ Wrong | ✅ Correct |
|----------|------------|
| 9876543210 | +919876543210 |
| 91-9876543210 | +919876543210 |
| (91) 9876543210 | +919876543210 |
| +91 9876543210 | +919876543210 |

**Always include country code and use + prefix!**

---

## 🎨 TEMPLATE VARIABLES

Use these in your messages:

| Variable | Replaced With |
|----------|---------------|
| `{name}` | Contact's name |
| `{phone}` | Contact's phone |

**Example:**
```
Template: "Hi {name}! Your number is {phone}"
Result:   "Hi John Doe! Your number is +919876543210"
```

---

## 🐛 QUICK FIXES

| Problem | Fix |
|---------|-----|
| Module not found | `pip install flask flask-cors` |
| npm error | `npm install` |
| Port in use | Change port in code |
| WhatsApp disconnected | Restart bot, scan QR |
| No messages sending | Check campaign is activated |
| Rate limit | Wait (this is normal!) |

---

## ✅ SUCCESS INDICATORS

You know it's working when:

✅ Terminal 1 shows: `Running on http://127.0.0.1:5050`  
✅ Terminal 2 shows: `WhatsApp Bulk Sender is ready!`  
✅ Dashboard shows: `Messages Sent Today: X`  
✅ WhatsApp contacts receive messages  
✅ Terminal 2 shows: `✅ [X/5] Sent to...`  

---

## 🎯 MOST COMMON COMMANDS

```bash
# Start system
python bulk_messaging_api.py          # Terminal 1
node whatsapp_bulk_bot.js            # Terminal 2

# Setup data
python quick_start.py

# Activate campaign (replace CAMPAIGN_ID)
curl -X POST http://localhost:5050/bulk/campaign/activate/CAMPAIGN_ID

# Check stats
curl http://localhost:5050/bulk/stats

# Stop system
Ctrl + C (in both terminals)
```

---

## 📊 DASHBOARD ACCESS

**Option 1:** Double-click `bulk_messaging_dashboard.html`  
**Option 2:** Open in browser: `file:///path/to/bulk_messaging_dashboard.html`  
**Option 3:** Use local server:
```bash
python -m http.server 8080
# Then open: http://localhost:8080/bulk_messaging_dashboard.html
```

---

## 🎉 THAT'S IT!

**Everything you need on one page!**

For detailed docs, see: `BULK_MESSAGING_README.md`  
For step-by-step guide, see: `HOW_TO_RUN.md`

**Questions?** Check the troubleshooting section in the full README!
