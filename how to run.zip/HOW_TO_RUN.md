# 🚀 HOW TO RUN - STEP BY STEP GUIDE

## 📋 Prerequisites

Before starting, make sure you have:
- ✅ Python 3.8 or higher installed
- ✅ Node.js 14 or higher installed
- ✅ WhatsApp installed on your phone
- ✅ A separate WhatsApp number (don't use your personal number!)

---

## 🎯 STEP 1: Download & Setup Files

### 1.1 Create a folder
```bash
# Create a folder for the project
mkdir whatsapp-bulk-messaging
cd whatsapp-bulk-messaging
```

### 1.2 Copy all files to this folder
Copy these files to your `whatsapp-bulk-messaging` folder:
- ✅ bulk_message_manager.py
- ✅ bulk_messaging_api.py
- ✅ whatsapp_bulk_bot.js
- ✅ bulk_messaging_dashboard.html
- ✅ package.json
- ✅ quick_start.py

---

## 🔧 STEP 2: Install Dependencies

### 2.1 Install Python packages

**Windows:**
```bash
pip install flask flask-cors
```

**Mac/Linux:**
```bash
pip install flask flask-cors --break-system-packages
```

You should see:
```
Successfully installed flask-3.x.x flask-cors-4.x.x
```

### 2.2 Install Node.js packages

```bash
npm install
```

You should see:
```
added 150+ packages
```

**This will install:**
- whatsapp-web.js (WhatsApp integration)
- qrcode-terminal (for QR codes)
- axios (for API calls)

---

## 🎬 STEP 3: Setup Example Data (Optional but Recommended)

Run this to create test contacts and templates:

```bash
python quick_start.py
```

You should see:
```
🚀 WHATSAPP BULK MESSAGING - QUICK START
📦 Initializing Bulk Message Manager...
✅ Manager initialized!
👥 Adding Example Contacts...
✅ Added 5 contacts
💬 Creating Message Templates...
✅ Created 5 templates
🚀 Creating Example Campaign...
✅ Campaign created: campaign_1234567890
```

**Note the Campaign ID!** You'll need it later.

---

## ▶️ STEP 4: Start the System

You need **3 terminals/command prompts** open:

### Terminal 1: Start API Server

```bash
python bulk_messaging_api.py
```

**Expected Output:**
```
🚀 WHATSAPP BULK MESSAGING API
================================================
📡 API Endpoints:
   Campaign: /bulk/campaign/*
   Contacts: /bulk/contacts/*
   Templates: /bulk/templates/*
   Sending: /bulk/next-batch, /bulk/log
   Stats: /bulk/stats
   Config: /bulk/config/*

🌐 Server starting on http://0.0.0.0:5050
================================================
```

**✅ Success!** Server is running. **Leave this terminal open!**

---

### Terminal 2: Start WhatsApp Bot

Open a **NEW** terminal/command prompt in the same folder:

```bash
node whatsapp_bulk_bot.js
```

**Expected Output:**
```
🚀 Initializing WhatsApp Bulk Sender...

📱 Scan this QR code with WhatsApp:

████ ▄▄▄▄▄ █ ▀ █ █ ▄▄▄▄▄ ████
████ █   █ █▀▄ ▀ █ █   █ ████
████ █▄▄▄█ █ ▄▀▀██ █▄▄▄█ ████
[... QR CODE APPEARS HERE ...]
```

### 4.1 Scan QR Code

1. **Open WhatsApp on your phone**
2. Tap **Settings** (or menu icon)
3. Tap **Linked Devices**
4. Tap **Link a Device**
5. **Point camera at QR code** on your computer screen

**After scanning:**
```
✅ WhatsApp Bulk Sender is ready!
📤 Starting bulk message sender...
```

**✅ Success!** WhatsApp is connected. **Leave this terminal open!**

---

### Terminal 3: Open Dashboard (Optional)

**Option A: Just open the HTML file**
1. Find `bulk_messaging_dashboard.html`
2. Double-click to open in browser

**Option B: Use Python simple server**
```bash
python -m http.server 8080
```
Then open browser to: `http://localhost:8080/bulk_messaging_dashboard.html`

---

## 🎯 STEP 5: Activate Your Campaign

Now that everything is running, activate your campaign:

### Option 1: Via Command Line (Easiest)

Open a **NEW** terminal (4th one) and run:

**Replace `campaign_1234567890` with YOUR campaign ID from Step 3:**

**Windows (PowerShell):**
```powershell
Invoke-WebRequest -Uri "http://localhost:5050/bulk/campaign/activate/campaign_1234567890" -Method POST
```

**Windows (cmd):**
```bash
curl -X POST http://localhost:5050/bulk/campaign/activate/campaign_1234567890
```

**Mac/Linux:**
```bash
curl -X POST http://localhost:5050/bulk/campaign/activate/campaign_1234567890
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Campaign activated"
}
```

### Option 2: Via Browser

Open browser and go to:
```
http://localhost:5050/bulk/campaign/activate/campaign_1234567890
```

---

## ✅ STEP 6: Verify It's Working

### 6.1 Check Terminal 2 (WhatsApp Bot)

You should see:
```
📤 Starting bulk message sender...
📨 Processing batch of 5 messages...

✅ [1/5] Sent to John Doe
⏳ Waiting 62s before next message...
✅ [2/5] Sent to Jane Smith
⏳ Waiting 58s before next message...
✅ [3/5] Sent to Bob Johnson
...
✅ Batch completed!
⏰ Next batch in 58 minutes...
```

### 6.2 Check Dashboard

Open `bulk_messaging_dashboard.html` and you should see:
- Messages Sent Today: 5
- Remaining Today: 43
- Sent This Hour: 5/5
- Active Campaigns: 1

### 6.3 Check Your WhatsApp

The contacts you added should receive messages!

---

## 📱 STEP 7: Add Your Own Contacts & Messages

### 7.1 Via Dashboard (Easiest)

1. Open `bulk_messaging_dashboard.html`
2. Click **"Contacts"** tab
3. Fill in:
   - Phone: `+919876543210` (include country code!)
   - Name: `John Doe`
   - Tags: `customer, vip`
4. Click **"Add Contact"**

### 7.2 Via Python Script

Create a file `add_my_contacts.py`:

```python
from bulk_message_manager import BulkMessageManager

manager = BulkMessageManager()

# Add your contacts
manager.add_contact('+919876543210', 'John Doe', ['customer'])
manager.add_contact('+919876543211', 'Jane Smith', ['customer'])
manager.add_contact('+919876543212', 'Bob Johnson', ['lead'])

print("✅ Contacts added!")
```

Run it:
```bash
python add_my_contacts.py
```

### 7.3 Via CSV Import

Create `my_contacts.csv`:
```csv
phone,name,tags
+919876543210,John Doe,"customer,vip"
+919876543211,Jane Smith,customer
+919876543212,Bob Johnson,lead
+919876543213,Alice Williams,customer
```

Import via dashboard or Python:
```python
manager.import_contacts_from_csv('my_contacts.csv')
```

---

## 🎨 STEP 8: Create Your Own Messages

### Via Dashboard:
1. Click **"Templates"** tab
2. Fill in:
   - Template ID: `my_promo`
   - Message: `Hi {name}! Special 50% discount for you today!`
3. Click **"Save Template"**

### Via Python:
```python
manager.add_template(
    'my_promo',
    'Hi {name}! Special 50% discount for you today!'
)
```

**Create 5 different messages for variety!**

---

## 🚀 STEP 9: Create Your Own Campaign

### Via Dashboard:
1. Click **"Campaigns"** tab
2. Fill in:
   - Campaign Name: `My Promotion`
   - Templates: Select your 5 templates (hold Ctrl)
   - Tags: `customer` (optional)
3. Click **"Create Campaign"**
4. Note the campaign ID
5. Activate it using Step 5 method

### Via Python:
```python
campaign_id = manager.create_campaign(
    'My Promotion',
    ['template1', 'template2', 'template3', 'template4', 'template5'],
    contact_tags=['customer']
)
print(f"Campaign ID: {campaign_id}")

# Activate it via curl command
```

---

## 🎛️ STEP 10: Control the Bot

### Via WhatsApp Commands

Send these messages to your WhatsApp bot:

**Check Status:**
```
bulk status
```

**Pause Sending:**
```
bulk pause
```

**Resume Sending:**
```
bulk resume
```

**Stop All:**
```
bulk stop
```

---

## 📊 Monitor Progress

### Method 1: Dashboard
Open `bulk_messaging_dashboard.html` - it auto-refreshes every 30 seconds

### Method 2: Check API
```bash
curl http://localhost:5050/bulk/stats
```

### Method 3: Terminal
Watch Terminal 2 (WhatsApp Bot) for real-time logs

---

## 🛑 How to Stop

### Stop Sending (Keep System Running)
Send to WhatsApp bot:
```
bulk pause
```

### Stop Everything
1. Press `Ctrl + C` in Terminal 2 (WhatsApp Bot)
2. Press `Ctrl + C` in Terminal 1 (API Server)

**Data is saved!** You can restart anytime.

---

## 🔄 How to Restart

Just run Step 4 again:
1. `python bulk_messaging_api.py` (Terminal 1)
2. `node whatsapp_bulk_bot.js` (Terminal 2)
3. Scan QR code
4. Your campaigns will resume automatically!

---

## 🐛 TROUBLESHOOTING

### Problem: "Module not found"

**Solution:**
```bash
# Install Python packages
pip install flask flask-cors

# Install Node packages
npm install
```

### Problem: "Port 5050 already in use"

**Solution:**
1. Close any program using port 5050
2. Or change port in `bulk_messaging_api.py`:
```python
app.run(host='0.0.0.0', port=5051, debug=True)
```

### Problem: "WhatsApp disconnected"

**Solution:**
1. Stop bot: `Ctrl + C`
2. Delete `.wwebjs_auth` folder
3. Restart: `node whatsapp_bulk_bot.js`
4. Scan QR code again

### Problem: "No messages sending"

**Check:**
1. Is campaign activated? (Step 5)
2. Are there contacts with matching tags?
3. Check Terminal 2 for errors
4. Check daily limit (48 messages/day)
5. Check hourly limit (5 messages/hour)

### Problem: "Rate limit reached"

**This is normal!** System is working correctly.
- Hourly limit: Wait 1 hour
- Daily limit: Wait until next day (00:00)

### Problem: "Invalid phone number"

**Make sure:**
- Include country code: `+91` for India, `+1` for USA
- Format: `+919876543210` (no spaces or dashes)

### Problem: "Campaign not found"

**Make sure:**
- You copied the correct campaign ID
- You ran `quick_start.py` first

---

## 📞 Quick Commands Reference

### Start Everything:
```bash
# Terminal 1
python bulk_messaging_api.py

# Terminal 2 (new terminal)
node whatsapp_bulk_bot.js

# Scan QR code with WhatsApp
```

### Activate Campaign:
```bash
curl -X POST http://localhost:5050/bulk/campaign/activate/CAMPAIGN_ID
```

### Check Status:
```bash
curl http://localhost:5050/bulk/stats
```

### Add Contact:
```bash
curl -X POST http://localhost:5050/bulk/contacts/add \
  -H "Content-Type: application/json" \
  -d '{"phone": "+919876543210", "name": "John Doe", "tags": ["customer"]}'
```

---

## ✅ Success Checklist

- ✅ Python packages installed
- ✅ Node packages installed
- ✅ API server running (Terminal 1)
- ✅ WhatsApp bot running (Terminal 2)
- ✅ QR code scanned
- ✅ Example data created (quick_start.py)
- ✅ Campaign activated
- ✅ Messages sending!

---

## 🎉 You're Done!

Your WhatsApp bulk messaging system is now running!

**The system will automatically:**
- Send 5 messages per hour
- Send up to 48 messages per day
- Rotate between your 5 message templates
- Add random delays to look natural
- Track everything in the dashboard

**Just leave it running and it does everything automatically!** 🚀

---

## 💡 Next Steps

1. Add your real contacts
2. Create your real message templates
3. Create your real campaign
4. Monitor the dashboard
5. Adjust settings as needed

**Need help?** Check the full documentation in `BULK_MESSAGING_README.md`
