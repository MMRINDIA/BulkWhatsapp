"""
Quick Start Script for WhatsApp Bulk Messaging
Run this to set up example data and start the system
"""
from bulk_message_manager import BulkMessageManager
import time

print("=" * 60)
print("🚀 WHATSAPP BULK MESSAGING - QUICK START")
print("=" * 60)
print()

# Initialize manager
print("📦 Initializing Bulk Message Manager...")
manager = BulkMessageManager()
print("✅ Manager initialized!\n")

# Add example contacts
print("👥 Adding Example Contacts...")
example_contacts = [
    {"phone": "+911234567890", "name": "John Doe", "tags": ["customer", "vip"]},
    {"phone": "+911234567891", "name": "Jane Smith", "tags": ["customer"]},
    {"phone": "+911234567892", "name": "Bob Johnson", "tags": ["lead"]},
    {"phone": "+911234567893", "name": "Alice Williams", "tags": ["customer"]},
    {"phone": "+911234567894", "name": "Charlie Brown", "tags": ["vip"]},
]

for contact in example_contacts:
    manager.add_contact(contact['phone'], contact['name'], contact['tags'])
    time.sleep(0.1)

print(f"✅ Added {len(example_contacts)} contacts\n")

# Add example templates
print("💬 Creating Message Templates...")
templates = {
    "welcome": "Hi {name}! 👋 Welcome to our service! We're excited to have you with us!",
    "offer": "Hey {name}! 🎁 Special offer just for you! Get 50% off on your next purchase!",
    "reminder": "Hello {name}, this is a friendly reminder about your upcoming appointment.",
    "followup": "{name}, following up on our last conversation. Hope you're doing well!",
    "thankyou": "Thank you {name} for being a valued customer! We appreciate your support! 🙏"
}

for template_id, message in templates.items():
    manager.add_template(template_id, message)
    time.sleep(0.1)

print(f"✅ Created {len(templates)} templates\n")

# Create example campaign
print("🚀 Creating Example Campaign...")
campaign_id = manager.create_campaign(
    campaign_name="Welcome Campaign",
    template_ids=list(templates.keys()),
    contact_tags=["customer"],  # Only send to customers
    start_time=None  # Start now
)
print(f"✅ Campaign created: {campaign_id}\n")

# Show current stats
print("📊 Current Statistics:")
stats = manager.get_daily_stats()
print(f"   Sent Today: {stats['sent_today']}/{stats['sent_today'] + stats['remaining_today']}")
print(f"   Remaining: {stats['remaining_today']}")
print(f"   This Hour: {stats['hourly_sent']}/{stats['hourly_sent'] + stats['hourly_remaining']}")
print()

# Show contacts
print("👥 Loaded Contacts:")
contacts = manager.get_contacts()
for contact in contacts[:5]:  # Show first 5
    print(f"   • {contact['name']} ({contact['phone']}) - Tags: {', '.join(contact.get('tags', []))}")
print()

# Show templates
print("💬 Loaded Templates:")
for template_id in manager.list_templates():
    print(f"   • {template_id}")
print()

# Instructions
print("=" * 60)
print("✅ SETUP COMPLETE!")
print("=" * 60)
print()
print("📝 Next Steps:")
print()
print("1️⃣  Start API Server:")
print("   Terminal 1: python bulk_messaging_api.py")
print()
print("2️⃣  Start WhatsApp Bot:")
print("   Terminal 2: node whatsapp_bulk_bot.js")
print()
print("3️⃣  Scan QR Code with WhatsApp")
print()
print("4️⃣  Activate Campaign:")
print(f"   curl -X POST http://localhost:5050/bulk/campaign/activate/{campaign_id}")
print()
print("5️⃣  Open Dashboard:")
print("   Open bulk_messaging_dashboard.html in browser")
print()
print("=" * 60)
print()
print("🎉 Your example campaign is ready!")
print("   • 5 contacts (4 customers, 1 lead)")
print("   • 5 message templates")
print("   • 1 campaign targeting customers")
print()
print("⚡ Activate the campaign to start sending!")
print()
print("💡 Tips:")
print("   • Check dashboard for real-time stats")
print("   • Send 'bulk status' to WhatsApp bot for updates")
print("   • System will send 5 messages per hour automatically")
print()
print("=" * 60)
