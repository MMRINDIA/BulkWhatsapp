# 📱 WhatsApp Bulk Messaging System

Smart bulk messaging system with intelligent rate limiting to **avoid WhatsApp blocking**.

## ✨ Features

- ✅ **Smart Rate Limiting**: 48 messages/day, 5 messages/hour
- ✅ **Message Rotation**: Use 5 different messages to appear more natural
- ✅ **Contact Management**: Import from CSV, add tags, filter
- ✅ **Template System**: Create reusable message templates
- ✅ **Campaign Management**: Schedule and monitor campaigns
- ✅ **Web Dashboard**: Easy-to-use interface
- ✅ **Analytics**: Track sent messages, success rate, etc.
- ✅ **Automatic Delays**: Randomized delays to appear human

## 🎯 Your Requirements

✅ Send bulk messages on WhatsApp  
✅ Time-bound: 48 messages per day  
✅ Rate limiting: 5 messages per hour  
✅ 10 hours = 48 messages  
✅ Message rotation: 5 different messages  
✅ Avoid WhatsApp blocking  
✅ Customizable messages  

## 📦 What You Get

1. **bulk_message_manager.py** - Core messaging logic
2. **whatsapp_bulk_bot.js** - WhatsApp bot integration
3. **bulk_messaging_api.py** - REST API backend
4. **bulk_messaging_dashboard.html** - Web dashboard
5. **package.json** - Node.js dependencies

## 🚀 Installation

### Step 1: Install Python Dependencies

```bash
pip install flask flask-cors --break-system-packages
```

### Step 2: Install Node.js Dependencies

```bash
npm install
```

## ⚙️ Setup

### Terminal 1: Start API Server

```bash
python bulk_messaging_api.py
```

Expected output:
```
🚀 WHATSAPP BULK MESSAGING API
📡 API Endpoints:
   Campaign: /bulk/campaign/*
   Contacts: /bulk/contacts/*
   Templates: /bulk/templates/*
🌐 Server starting on http://0.0.0.0:5050
```

### Terminal 2: Start WhatsApp Bot

```bash
node whatsapp_bulk_bot.js
```

Expected output:
```
🚀 Initializing WhatsApp Bulk Sender...
📱 Scan this QR code with WhatsApp:
[QR CODE APPEARS]
```

### Step 3: Scan QR Code

1. Open WhatsApp on your phone
2. Go to Settings → Linked Devices
3. Tap "Link a Device"
4. Scan the QR code

### Step 4: Open Dashboard

```bash
# Open in browser
bulk_messaging_dashboard.html
```

Or visit: `file:///path/to/bulk_messaging_dashboard.html`

## 📱 How to Use

### 1. Add Contacts

**Method 1: Web Dashboard**
- Go to "Contacts" tab
- Fill in phone number, name, tags
- Click "Add Contact"

**Method 2: CSV Import**
Create a CSV file with format:
```csv
phone,name,tags
+911234567890,John Doe,customer,vip
+919876543210,Jane Smith,lead
```

Then import via dashboard.

**Method 3: API**
```bash
curl -X POST http://localhost:5050/bulk/contacts/add \
  -H "Content-Type: application/json" \
  -d '{"phone": "+911234567890", "name": "John Doe", "tags": ["customer"]}'
```

### 2. Create Message Templates

**Via Dashboard:**
- Go to "Templates" tab
- Enter Template ID (e.g., "welcome_msg")
- Enter message (use {name} for personalization)
- Click "Save Template"

**Example Templates:**
```
Template 1 (ID: welcome):
Hi {name}! 👋 Welcome to our service!

Template 2 (ID: offer):
Hey {name}! 🎁 Special offer just for you!

Template 3 (ID: reminder):
Hello {name}, this is a friendly reminder...

Template 4 (ID: followup):
{name}, following up on our last conversation...

Template 5 (ID: thankyou):
Thank you {name} for being a valued customer!
```

### 3. Create Campaign

**Via Dashboard:**
- Go to "Campaigns" tab
- Enter campaign name
- Select multiple templates (hold Ctrl/Cmd)
- Add tags to filter contacts (optional)
- Click "Create Campaign"

**Via API:**
```bash
curl -X POST http://localhost:5050/bulk/campaign/create \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Welcome Campaign",
    "templates": ["welcome", "offer", "reminder", "followup", "thankyou"],
    "tags": ["customer"]
  }'
```

Response:
```json
{
  "success": true,
  "campaign_id": "campaign_1707507600"
}
```

### 4. Activate Campaign

```bash
curl -X POST http://localhost:5050/bulk/campaign/activate/campaign_1707507600
```

### 5. Monitor Progress

**Via Dashboard:**
- Check "Dashboard" tab for real-time stats
- View sent/remaining messages
- Track hourly and daily limits

**Via WhatsApp Commands:**
Send to your WhatsApp bot:
- `bulk status` - Get current stats
- `bulk pause` - Pause sending
- `bulk resume` - Resume sending
- `bulk stop` - Stop all campaigns

## 🔧 Configuration

### Default Settings

```python
{
    'daily_limit': 48,           # Max messages per day
    'hourly_limit': 5,           # Max messages per hour
    'messages_per_batch': 5,     # Messages sent together
    'delay_between_messages': 60, # Seconds (1 minute)
    'delay_between_batches': 3600, # Seconds (1 hour)
    'randomize_delay': True,     # Add ±20% randomization
    'rotate_messages': True      # Use different templates
}
```

### Customize via Dashboard

1. Go to "Settings" tab
2. Modify values
3. Click "Save Configuration"

## 📊 How It Works

### Message Flow

```
1. Create Campaign
   ↓
2. Bot gets next batch (5 messages)
   ↓
3. Send message #1 → Wait 1 minute
   ↓
4. Send message #2 → Wait 1 minute
   ↓
5. Send message #3 → Wait 1 minute
   ↓
6. Send message #4 → Wait 1 minute
   ↓
7. Send message #5
   ↓
8. Wait 1 hour
   ↓
9. Repeat (next 5 messages)
```

### Timing Example

**Day 1:**
```
08:00 AM - Batch 1 (5 messages) → Messages 1-5
09:00 AM - Batch 2 (5 messages) → Messages 6-10
10:00 AM - Batch 3 (5 messages) → Messages 11-15
11:00 AM - Batch 4 (5 messages) → Messages 16-20
12:00 PM - Batch 5 (5 messages) → Messages 21-25
01:00 PM - Batch 6 (5 messages) → Messages 26-30
02:00 PM - Batch 7 (5 messages) → Messages 31-35
03:00 PM - Batch 8 (5 messages) → Messages 36-40
04:00 PM - Batch 9 (5 messages) → Messages 41-45
05:00 PM - Batch 10 (3 messages) → Messages 46-48

Total: 48 messages in 10 hours
```

## 🛡️ Anti-Blocking Features

### 1. Rate Limiting
- Never exceed 5 messages/hour
- Never exceed 48 messages/day
- Spread messages over 10 hours

### 2. Randomization
- ±20% delay variance
- Messages sent 48-72 seconds apart (not exactly 60s)
- Batches sent 54-66 minutes apart (not exactly 60m)

### 3. Message Rotation
- 5 different message templates
- Each contact gets varied message
- More natural appearance

### 4. Human-like Behavior
- Realistic delays
- Varied message content
- No rapid-fire sending

## 📈 Analytics

### Dashboard Stats

```
Messages Sent Today: 24/48
Remaining Today: 24
Sent This Hour: 3/5
Active Campaigns: 2
```

### Campaign Stats

```
Campaign: Welcome Campaign
Status: Active
Total: 100 messages
Sent: 45
Failed: 2
Remaining: 55
Success Rate: 95.6%
```

## 🔥 Example Use Cases

### Use Case 1: Customer Onboarding

```python
# Add customers
contacts = [
    {"phone": "+91...", "name": "John", "tags": ["new_customer"]},
    {"phone": "+91...", "name": "Jane", "tags": ["new_customer"]},
]

# Create templates
templates = [
    "Hi {name}! Welcome aboard!",
    "Hey {name}! Thanks for joining us!",
    "Hello {name}, great to have you!",
    "{name}, welcome to our community!",
    "Hi {name}! Your journey starts here!"
]

# Create campaign
manager.create_campaign(
    "Customer Onboarding",
    ["template1", "template2", "template3", "template4", "template5"],
    ["new_customer"]
)
```

### Use Case 2: Promotional Offers

```python
# Filter VIP customers
tags = ["vip", "premium"]

# Create offer templates
templates = [
    "Exclusive offer for {name}! 50% OFF!",
    "{name}, special VIP discount just for you!",
    "Hey {name}! Limited time offer inside!",
]

# Send to VIPs only
manager.create_campaign("VIP Promotion", templates, tags)
```

### Use Case 3: Event Reminders

```python
# Event attendees
tags = ["event_registered"]

# Reminder templates
templates = [
    "{name}, event is tomorrow at 5 PM!",
    "Don't forget {name}, see you tomorrow!",
    "Reminder {name}: Event starts tomorrow!",
]

manager.create_campaign("Event Reminder", templates, tags)
```

## 🐛 Troubleshooting

### Issue: "Rate limit reached"

**Solution:** Wait for the next hour. System automatically resumes.

### Issue: "Daily limit reached"

**Solution:** Wait until next day (00:00). Limit resets automatically.

### Issue: "WhatsApp disconnected"

**Solution:**
1. Check if QR code needs rescanning
2. Restart bot: `node whatsapp_bulk_bot.js`
3. Scan QR code again

### Issue: "Message failed to send"

**Reasons:**
- Invalid phone number
- Contact blocked you
- WhatsApp down temporarily

**Solution:** Check logs, message will be retried automatically.

### Issue: "No contacts in campaign"

**Solution:** Check contact tags match campaign tags.

## 📝 API Endpoints

### Contacts

```bash
POST /bulk/contacts/add
POST /bulk/contacts/bulk-add
POST /bulk/contacts/import-csv
GET  /bulk/contacts/list
DELETE /bulk/contacts/remove
```

### Templates

```bash
POST /bulk/templates/add
GET  /bulk/templates/list
```

### Campaigns

```bash
POST /bulk/campaign/create
POST /bulk/campaign/activate/<id>
POST /bulk/campaign/pause/<id>
GET  /bulk/campaign/stats/<id>
```

### Sending

```bash
GET  /bulk/next-batch
POST /bulk/log
GET  /bulk/stats
```

## 🎨 Customization

### Change Daily Limit

```python
# In bulk_messaging_api.py
manager.config['daily_limit'] = 100  # Increase to 100/day
```

### Change Message Delay

```python
# More aggressive (30 seconds between messages)
manager.config['delay_between_messages'] = 30

# More conservative (2 minutes between messages)
manager.config['delay_between_messages'] = 120
```

### Disable Randomization

```python
manager.config['randomize_delay'] = False
```

## 📊 Data Storage

All data stored in `~/.aiden/bulk_messages/`:

```
~/.aiden/bulk_messages/
├── contacts.json          # All contacts
├── message_templates.json # Message templates
├── message_queue.json     # Active campaigns
└── sent_log.json         # Sent message history
```

## ⚠️ Important Notes

### WhatsApp Limits

1. **Official Limits:** WhatsApp may ban accounts sending too many messages
2. **Our Safeguards:** 48/day and 5/hour are conservative limits
3. **Be Careful:** Don't use with your personal number
4. **Recommendation:** Use a separate number for bulk messaging

### Legal Compliance

1. ✅ Get consent before messaging
2. ✅ Provide opt-out option
3. ✅ Follow local spam laws
4. ✅ Don't send promotional content without permission

### Best Practices

1. Use opt-in contacts only
2. Personalize messages with {name}
3. Rotate message templates
4. Monitor bounce/block rates
5. Don't send during night hours
6. Include unsubscribe instructions

## 🚀 Pro Tips

### 1. Gradual Start

Start with 10-20 messages/day for first week, then increase to 48.

### 2. Message Quality

Better to send 10 high-quality personalized messages than 100 spam messages.

### 3. Engagement Tracking

Monitor reply rates. If low, improve message content.

### 4. A/B Testing

Create 2 campaigns with different templates, see which performs better.

### 5. Scheduling

Create campaigns in advance, activate when ready.

## 📞 Support

- Issue: Check logs in terminal
- Bug: Review API responses
- Feature request: Modify code as needed

## 📄 License

MIT License - Free to use and modify!

---

**Ready to start?** Follow the installation steps above! 🚀

Questions? The system is fully customizable - just modify the Python/JavaScript code as needed!
