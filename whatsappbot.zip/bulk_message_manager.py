"""
WhatsApp Bulk Message Manager
Smart bulk messaging with rate limiting to avoid blocking
"""
import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional
import random


class BulkMessageManager:
    """
    Manages bulk WhatsApp messages with smart rate limiting
    
    Features:
    - Daily limit: 48 messages
    - Hourly limit: 5 messages (to avoid blocking)
    - Message rotation (use different messages)
    - Contact management
    - Scheduling
    - Analytics
    """
    
    def __init__(self, storage_path: Optional[str] = None):
        """Initialize bulk message manager"""
        if storage_path is None:
            storage_path = Path.home() / '.aiden' / 'bulk_messages'
        
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Configuration
        self.config = {
            'daily_limit': 48,
            'hourly_limit': 5,
            'messages_per_batch': 5,
            'delay_between_messages': 60,  # seconds (1 minute)
            'delay_between_batches': 3600,  # seconds (1 hour)
            'randomize_delay': True,
            'rotate_messages': True
        }
        
        # Storage files
        self.contacts_file = self.storage_path / 'contacts.json'
        self.templates_file = self.storage_path / 'message_templates.json'
        self.queue_file = self.storage_path / 'message_queue.json'
        self.sent_log_file = self.storage_path / 'sent_log.json'
        
        # Load data
        self.contacts = self._load_contacts()
        self.templates = self._load_templates()
        self.queue = self._load_queue()
        self.sent_log = self._load_sent_log()
    
    # ==================== CONTACT MANAGEMENT ====================
    
    def add_contact(self, phone: str, name: str = "", tags: List[str] = None) -> bool:
        """
        Add a contact to the list
        
        Args:
            phone: Phone number (with country code)
            name: Contact name
            tags: List of tags for segmentation
            
        Returns:
            True if added successfully
        """
        if tags is None:
            tags = []
        
        contact_id = self._normalize_phone(phone)
        
        self.contacts[contact_id] = {
            'phone': phone,
            'name': name,
            'tags': tags,
            'added_date': datetime.now().isoformat(),
            'last_sent': None,
            'total_sent': 0,
            'active': True
        }
        
        self._save_contacts()
        print(f"✅ Added contact: {name or phone}")
        return True
    
    def add_contacts_bulk(self, contacts_list: List[Dict]) -> int:
        """
        Add multiple contacts at once
        
        Args:
            contacts_list: List of dicts with 'phone', 'name', 'tags'
            
        Returns:
            Number of contacts added
        """
        added = 0
        for contact in contacts_list:
            phone = contact.get('phone')
            name = contact.get('name', '')
            tags = contact.get('tags', [])
            
            if phone:
                self.add_contact(phone, name, tags)
                added += 1
        
        print(f"✅ Added {added} contacts")
        return added
    
    def import_contacts_from_csv(self, csv_file: str) -> int:
        """Import contacts from CSV file"""
        import csv
        
        added = 0
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                phone = row.get('phone') or row.get('Phone') or row.get('number')
                name = row.get('name') or row.get('Name', '')
                tags = row.get('tags', '').split(',') if row.get('tags') else []
                
                if phone:
                    self.add_contact(phone, name, tags)
                    added += 1
        
        print(f"✅ Imported {added} contacts from {csv_file}")
        return added
    
    def remove_contact(self, phone: str) -> bool:
        """Remove contact from list"""
        contact_id = self._normalize_phone(phone)
        
        if contact_id in self.contacts:
            del self.contacts[contact_id]
            self._save_contacts()
            print(f"✅ Removed contact: {phone}")
            return True
        
        print(f"❌ Contact not found: {phone}")
        return False
    
    def get_contacts(self, tags: List[str] = None, active_only: bool = True) -> List[Dict]:
        """
        Get contacts (optionally filtered by tags)
        
        Args:
            tags: Filter by tags
            active_only: Only return active contacts
            
        Returns:
            List of contacts
        """
        contacts = []
        
        for contact_id, contact in self.contacts.items():
            # Filter by active status
            if active_only and not contact.get('active', True):
                continue
            
            # Filter by tags
            if tags:
                contact_tags = contact.get('tags', [])
                if not any(tag in contact_tags for tag in tags):
                    continue
            
            contacts.append(contact)
        
        return contacts
    
    # ==================== MESSAGE TEMPLATES ====================
    
    def add_template(self, template_id: str, message: str, variables: List[str] = None) -> bool:
        """
        Add a message template
        
        Args:
            template_id: Unique ID for template
            message: Message text (use {name}, {phone} for variables)
            variables: List of variable names used in message
            
        Returns:
            True if added successfully
        """
        if variables is None:
            variables = []
        
        self.templates[template_id] = {
            'message': message,
            'variables': variables,
            'created_date': datetime.now().isoformat(),
            'used_count': 0
        }
        
        self._save_templates()
        print(f"✅ Added template: {template_id}")
        return True
    
    def get_template(self, template_id: str) -> Optional[str]:
        """Get a message template"""
        template = self.templates.get(template_id)
        return template['message'] if template else None
    
    def list_templates(self) -> List[str]:
        """List all template IDs"""
        return list(self.templates.keys())
    
    def format_message(self, template_id: str, contact: Dict) -> str:
        """
        Format message with contact data
        
        Args:
            template_id: Template ID
            contact: Contact dict
            
        Returns:
            Formatted message
        """
        template = self.templates.get(template_id)
        if not template:
            return ""
        
        message = template['message']
        
        # Replace variables
        message = message.replace('{name}', contact.get('name', 'there'))
        message = message.replace('{phone}', contact.get('phone', ''))
        
        return message
    
    # ==================== CAMPAIGN MANAGEMENT ====================
    
    def create_campaign(
        self,
        campaign_name: str,
        template_ids: List[str],
        contact_tags: List[str] = None,
        start_time: Optional[datetime] = None
    ) -> str:
        """
        Create a bulk message campaign
        
        Args:
            campaign_name: Name of campaign
            template_ids: List of template IDs to rotate
            contact_tags: Tags to filter contacts (None = all contacts)
            start_time: When to start (None = now)
            
        Returns:
            Campaign ID
        """
        if start_time is None:
            start_time = datetime.now()
        
        # Get contacts
        contacts = self.get_contacts(tags=contact_tags)
        
        if not contacts:
            print("❌ No contacts found with specified tags")
            return ""
        
        # Create campaign
        campaign_id = f"campaign_{int(time.time())}"
        
        campaign = {
            'id': campaign_id,
            'name': campaign_name,
            'template_ids': template_ids,
            'contacts': [c['phone'] for c in contacts],
            'start_time': start_time.isoformat(),
            'status': 'scheduled',
            'total_messages': len(contacts),
            'sent_count': 0,
            'failed_count': 0,
            'created_date': datetime.now().isoformat()
        }
        
        # Add to queue
        self.queue[campaign_id] = campaign
        self._save_queue()
        
        print(f"✅ Campaign created: {campaign_name}")
        print(f"   ID: {campaign_id}")
        print(f"   Contacts: {len(contacts)}")
        print(f"   Templates: {len(template_ids)}")
        print(f"   Start: {start_time}")
        
        return campaign_id
    
    def get_next_batch(self) -> List[Dict]:
        """
        Get next batch of messages to send
        
        Returns:
            List of messages to send (max 5)
        """
        # Check daily limit
        today_sent = self._get_today_sent_count()
        if today_sent >= self.config['daily_limit']:
            print(f"⚠️  Daily limit reached ({self.config['daily_limit']})")
            return []
        
        # Check hourly limit
        hour_sent = self._get_hour_sent_count()
        if hour_sent >= self.config['hourly_limit']:
            print(f"⚠️  Hourly limit reached ({self.config['hourly_limit']})")
            return []
        
        # Get active campaigns
        batch = []
        remaining_slots = min(
            self.config['messages_per_batch'],
            self.config['daily_limit'] - today_sent,
            self.config['hourly_limit'] - hour_sent
        )
        
        for campaign_id, campaign in self.queue.items():
            if campaign['status'] != 'active':
                continue
            
            if len(batch) >= remaining_slots:
                break
            
            # Get next contact to message
            sent_count = campaign['sent_count']
            contacts = campaign['contacts']
            
            if sent_count >= len(contacts):
                campaign['status'] = 'completed'
                continue
            
            contact_phone = contacts[sent_count]
            contact = self.contacts.get(self._normalize_phone(contact_phone))
            
            if not contact:
                campaign['sent_count'] += 1
                continue
            
            # Select template (rotate)
            template_ids = campaign['template_ids']
            template_id = template_ids[sent_count % len(template_ids)]
            
            # Format message
            message = self.format_message(template_id, contact)
            
            batch.append({
                'campaign_id': campaign_id,
                'contact': contact,
                'message': message,
                'template_id': template_id
            })
            
            campaign['sent_count'] += 1
        
        self._save_queue()
        return batch
    
    def activate_campaign(self, campaign_id: str) -> bool:
        """Start a campaign"""
        if campaign_id not in self.queue:
            print(f"❌ Campaign not found: {campaign_id}")
            return False
        
        self.queue[campaign_id]['status'] = 'active'
        self._save_queue()
        
        print(f"✅ Campaign activated: {campaign_id}")
        return True
    
    def pause_campaign(self, campaign_id: str) -> bool:
        """Pause a campaign"""
        if campaign_id not in self.queue:
            return False
        
        self.queue[campaign_id]['status'] = 'paused'
        self._save_queue()
        
        print(f"⏸️  Campaign paused: {campaign_id}")
        return True
    
    # ==================== SENDING & LOGGING ====================
    
    def log_sent_message(self, campaign_id: str, contact: Dict, success: bool, error: str = None):
        """Log a sent message"""
        log_entry = {
            'campaign_id': campaign_id,
            'contact_phone': contact['phone'],
            'contact_name': contact.get('name', ''),
            'success': success,
            'error': error,
            'timestamp': datetime.now().isoformat()
        }
        
        self.sent_log.append(log_entry)
        
        # Update contact last_sent
        contact_id = self._normalize_phone(contact['phone'])
        if contact_id in self.contacts:
            self.contacts[contact_id]['last_sent'] = datetime.now().isoformat()
            self.contacts[contact_id]['total_sent'] += 1
        
        # Update campaign stats
        if campaign_id in self.queue:
            if not success:
                self.queue[campaign_id]['failed_count'] += 1
        
        self._save_sent_log()
        self._save_contacts()
        self._save_queue()
    
    # ==================== ANALYTICS ====================
    
    def get_campaign_stats(self, campaign_id: str) -> Dict:
        """Get campaign statistics"""
        campaign = self.queue.get(campaign_id)
        if not campaign:
            return {}
        
        return {
            'name': campaign['name'],
            'status': campaign['status'],
            'total_messages': campaign['total_messages'],
            'sent': campaign['sent_count'],
            'failed': campaign['failed_count'],
            'remaining': campaign['total_messages'] - campaign['sent_count'],
            'success_rate': (campaign['sent_count'] - campaign['failed_count']) / max(campaign['sent_count'], 1) * 100
        }
    
    def get_daily_stats(self) -> Dict:
        """Get today's statistics"""
        today_sent = self._get_today_sent_count()
        
        return {
            'date': datetime.now().date().isoformat(),
            'sent_today': today_sent,
            'remaining_today': self.config['daily_limit'] - today_sent,
            'hourly_sent': self._get_hour_sent_count(),
            'hourly_remaining': self.config['hourly_limit'] - self._get_hour_sent_count()
        }
    
    # ==================== UTILITY METHODS ====================
    
    def _normalize_phone(self, phone: str) -> str:
        """Normalize phone number"""
        return ''.join(filter(str.isdigit, phone))
    
    def _get_today_sent_count(self) -> int:
        """Count messages sent today"""
        today = datetime.now().date()
        count = 0
        
        for log in self.sent_log:
            log_date = datetime.fromisoformat(log['timestamp']).date()
            if log_date == today and log.get('success', False):
                count += 1
        
        return count
    
    def _get_hour_sent_count(self) -> int:
        """Count messages sent in the last hour"""
        one_hour_ago = datetime.now() - timedelta(hours=1)
        count = 0
        
        for log in self.sent_log:
            log_time = datetime.fromisoformat(log['timestamp'])
            if log_time > one_hour_ago and log.get('success', False):
                count += 1
        
        return count
    
    def _load_contacts(self) -> Dict:
        """Load contacts from file"""
        if self.contacts_file.exists():
            with open(self.contacts_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_contacts(self):
        """Save contacts to file"""
        with open(self.contacts_file, 'w') as f:
            json.dump(self.contacts, f, indent=2)
    
    def _load_templates(self) -> Dict:
        """Load templates from file"""
        if self.templates_file.exists():
            with open(self.templates_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_templates(self):
        """Save templates to file"""
        with open(self.templates_file, 'w') as f:
            json.dump(self.templates, f, indent=2)
    
    def _load_queue(self) -> Dict:
        """Load message queue from file"""
        if self.queue_file.exists():
            with open(self.queue_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_queue(self):
        """Save message queue to file"""
        with open(self.queue_file, 'w') as f:
            json.dump(self.queue, f, indent=2)
    
    def _load_sent_log(self) -> List:
        """Load sent log from file"""
        if self.sent_log_file.exists():
            with open(self.sent_log_file, 'r') as f:
                return json.load(f)
        return []
    
    def _save_sent_log(self):
        """Save sent log to file"""
        # Keep only last 1000 entries
        self.sent_log = self.sent_log[-1000:]
        
        with open(self.sent_log_file, 'w') as f:
            json.dump(self.sent_log, f, indent=2)


if __name__ == '__main__':
    # Demo
    manager = BulkMessageManager()
    
    print("=== WhatsApp Bulk Message Manager Demo ===\n")
    
    # Add contacts
    manager.add_contact('+1234567890', 'John Doe', ['customer'])
    manager.add_contact('+0987654321', 'Jane Smith', ['lead'])
    
    # Add templates
    manager.add_template('welcome', 'Hi {name}! Welcome to our service! 🎉')
    manager.add_template('offer', 'Hey {name}! Special offer just for you! 🎁')
    
    # Create campaign
    campaign_id = manager.create_campaign(
        'Welcome Campaign',
        ['welcome', 'offer'],
        contact_tags=['customer']
    )
    
    # Get stats
    stats = manager.get_daily_stats()
    print(f"\nDaily Stats: {stats}")
